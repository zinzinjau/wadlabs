/**let age =20;
//var course ="BBIT";
//const university ="Strathmore University";
//an external js file (.js)(.css)(.html)
// variables and types
// scope (const & let are block scoped, )var is global
//let age =22;
//ar course ="BCIS";
//const university ="Strathmore University";

//age=40;
//course="BBA";

//if(true){
    //let time ="1:30";
//var day ="4th";
    //const year =2026;
}
//console.log(time);
console.log(day);
console.log(year);*/

/** @param{int} length
*@param{int}width
*@returns area 
 */  


// function definition
function calculateArea(length, width){
    if(length ==null){
        console.log('height missing!')
    }else if (width == null){
        console.log('width missing!')
    } else{ 
        let area = length * width;
    return area;

    }
    
    //console.log("Function calculateArea ");
    //alert("Function called/ executed");
}
// returning a value is not printing out
// function call executtion called
console.log(calculateArea(20,3));// a function call
console.log(calculateArea(20));
console.log(calculateArea());
// function expression
const add = function( number1, number2){
    return number1 + number2;
}

console.log(add(4,2));

// arrow function
const multiply = (x, y) => x * y;
console.log(multiply(4,2));

/** Javascript arrays (related) */
const scores = [45, 56 , 67, 67, 78];

//access
//78 
console.log (scores[5])
//67
console.log (scores[3])

//45
console.log (scores[1])

let student_names = ["omondi","wafula", "kiporticj", "nyamebane","toipan",]

console.log (student_names[3])

let governers = [
    [47, "johnson sakaja"],
    [1, "abdullswamad sherrif"],
   // {21, "irungu kangata"}
]

// governer of county one is abdull blah blah

console.log("the govonor of county number", governers[1][0], "is" , governers[1] [1])

//map (perform an operation on each element)

let double = scores.map(x => x*2) //multiply each score by 2
console.log(double)

//properties
//the class has J students

console.log("the class has", student_names, length, "students");

//kenya has b governers

console.log("kenya has", governers,length, "governers")

//for

for (let index in scores) {
    console.log(scores[index])
}

//for of
for (let score of scores) {
    console.log(scores)
}

//for each
scores.forEach(function(score){
    console.log("score ;", score)
})

const student = {
    name : 'Alice',
    age : 20 ,
    passed : true,
    grade : "A",
    "admission number" : 183380,
    coure : "BBIT",
    group : "2A",
    attendance : 20,
    attendance : function() {
        this.attendance += 1 ;
    }
};

//accessing items
//student name
console.log('my name is', student.name,'from',student["admission number"], "university"
)

//methos in the object

student.addAttendance(); //add attendance  by 1
console.log(student.attendance)

//array of objects



let bbit_2b = [
 {adm: 223251 , name : "blessing"},
 {adm: 192997 , name :"blessing"},
 {adm: 222024 , name : "blessing"},
  {adm: 220941 , name : "blessing"},
 
]
//@TO DO SHOW LOOPING OF OBJECTS
//print out all names of all students in bbit 2b using a loop
console.log(Object.keys(student))

console.log(Object.values(student))

console.log(Object.entries(student))

//DOM THINGS
console.log(document)
console.log(document)

const heading = document.querySelector("#mainHeading")
console.log(heading)

const previewImage = document.querySelector("image")
console.log(previewImage)

const aboutSection = document.getElementById('about')
console.log(aboutSection)

const allSections = document.querySelectorAll('section');
console.log(allSections);

const allNavLinks = document.querySelectorAll('nav a');
console.log(allNavLinks);

let aboutParagraph = document.querySelector("#about p");

// change its text
aboutParagraph.textContent = "This text was changed!";
aboutParagraph.style.color = "red";

//setteing/ setter - updating the page from js
//via dom
previewImage.setAttribute("title", "new title of image");
previewImage.setAttribute("alt", "new alternive text for the image");
console.log(previewImage.alt);
console.log(previewImage.title);

//event handling - events (user eventa - click key events, scroll)

//get the element of interest - button with an id of changetxbutton

let changetxbutton = document.querySelector("#changeTextBtn")
let demoText = document.querySelector("#demoText")
//we are handling the click event for the button with an id of changeTextbtn
changetxbutton.addEventListener("click", function (events){
    console.log("someone clicked meeee")
    demoText.textContent = "I have been changed when you clicked"
    demoText.style.color = "Orange"
    demoText.style.fontSize = "16px"
})

let highlightSectionBtn = document.querySelector("#highlightsSectionsBtn");
highlightSectionBtn.addEventListener("click", function(event){
    //one
    document.querySelector("#about").classList.toggle("section-highlight")
    //two
    
//document.querySelectorAll("section").classList.toggle("section-highlight")

document.querySelectorAll("section").forEach(function(section){
    section.classList.toggle("section-highlight")
})

});

//get the textbox with id nameInput

document.querySelector("#nameOutput").addEventListener("input", function(event){

    document.querySelector("#liveOut").textContent=  "hello" + document.querySelector("#nameOutput").value + "!";
});

// case 4- character counter

 let gtaCommentTextArea = document.querySelector("#commentInput");
 let charCountParagraph = document.querySelector("#charCount");
gtaCommentTextArea.addEventListener("input",function(e){
// code goes here a.k.a what will be executed when the
// event happens

//console.log("typing...");
// count the number of characters
 let numberOfChars = gtaCommentTextArea.value.length;
 
 // update the paragraph
 charCountParagraph.textContent = "Characters: " + numberOfChars;

 // prevent the user from typing after 60
    if(numberOfChars >=60){
        e.preventDefault();
        gtaCommentTextArea.readOnly = true;
    }else{
        // update the paragraph
        charCountParagraph.textContent = "Characters: " + numberOfChars;
    }
});

// case 5 - keyboard events
let keyOutputParagraph = document.querySelector("#keyOutput");
// the event listener
// when you press a key,anywhere on the page since we have attached it to the entire page not just one element
document.addEventListener("keydown",function(event){
    keyOutputParagraph.textContent = "You pressed: " + event.key;
});

// case 6- todo list,wish list
let wishListInput = document.querySelector("#wishlistInput");
let wishListButton = document.querySelector("#wishlistForm button");
//<ul> </ul>
let wishListItems = document.querySelector("#wishlistItems");
console.log(wishListButton);

 wishListButton.addEventListener("click",function(event){
    event.preventDefault();

    let wishListInputValue = wishListInput.value;
// whats the difference between != " and null"
    if(wishListInputValue!= ""){
//console.log(wishListInputValue);

let li=document.createElement("li");
let button=document.createElement("button");
button.textContent="Delete";
li.textContent = wishListInputValue;

li.appendChild(button);

// append the list to the UL
wishListItems.appendChild(li);
//clear what the user typed
wishListInput.value = "";
    }
    
});

// case 6b - removing items from the wish list
let deleteButtons = document.querySelectorAll('#wishlistItems button');
console.log(deleteButtons);

// iterate a.k.a loop through the buttons
deleteButtons.forEach(button => {
    button.addEventListener("click", event => {
        // console.log("delete button clicked");
        // get the parent list item of the clicked button
        let listItem = event.target.closest('li');
        // remove the list item
        listItem.remove();
    });
});

// forgotten
let resetBtn = document.querySelector("#resetBtn");
resetBtn.addEventListener("click", event => {
    // undo the changed text
    demoText.textContent =
        "Click the button to modify this text using JavaScript.";
    demoText.style.color = "white";
    demoText.style.fontSize = "16px"; //has no effect
 
    //undo the highlight of the sections
    // toggle will remove if present or add if absent
    document.querySelectorAll("section").forEach(function (section) {
        // section.classList.toggle("section-highlight");
        section.classList.remove("section-highlight");
    });
});
 